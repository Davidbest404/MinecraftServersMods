scoreboard objectives add sit_sit dummy
scoreboard objectives add sit_permiss dummy
scoreboard objectives add sit_timer dummy
scoreboard objectives add sit_mode_switch trigger
scoreboard objectives add sit trigger