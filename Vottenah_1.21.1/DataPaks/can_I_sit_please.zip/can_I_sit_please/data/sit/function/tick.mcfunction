scoreboard players enable @a sit_mode_switch
scoreboard players enable @a sit
#Усидка по /trigger sit
execute as @a[scores={sit=1..}] at @s unless block ~ ~-0.1 ~ #minecraft:air run function sit:apply_sit
execute as @a[scores={sit=1..}] run scoreboard players set @s sit 0

#Оповещение о смене режима
execute as @a[scores={sit_mode_switch=1}] run tellraw @s {"text":"Вы выключили двойное нажатие SHIFT для сидения","color":"red"}
execute as @a[scores={sit_mode_switch=1}] run scoreboard players set @s sit_mode_switch 2
execute as @a[scores={sit_mode_switch=3}] run tellraw @s {"text":"Вы включили двойное нажатие SHIFT для сидения","color":"green"}
execute as @a[scores={sit_mode_switch=3..}] run scoreboard players set @s sit_mode_switch 0

execute as @a[scores={sit_mode_switch=0}] run function sit:shift

execute as @e[type=armor_stand,tag=sit] at @s positioned ~ ~1.7 ~ unless entity @a[distance=..0.4,limit=1] run kill @s
execute as @e[type=armor_stand,tag=sit] at @s positioned ~ ~1.7 ~ run data modify entity @s Rotation set from entity @a[distance=..0.4,limit=1] Rotation