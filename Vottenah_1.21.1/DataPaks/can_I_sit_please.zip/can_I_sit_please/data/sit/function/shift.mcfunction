#Счётчик нажатий
execute as @a[predicate=sit:sneak] if score @s sit_permiss matches 0 run scoreboard players add @s sit_sit 1

#Таймер при нажатии shift
execute as @a[predicate=sit:sneak] if score @s sit_permiss matches 0 run tag @s add press_shift
execute as @a[tag=press_shift] run scoreboard players add @s sit_timer 1

#Проверка во время таймера
execute as @a at @s unless block ~ ~-0.1 ~ #air if score @s sit_sit matches 2.. if score @s sit_timer matches 1..8 if score @s sit_permiss matches 0 run function sit:apply_sit

#Выключение таймера
execute as @a[tag=press_shift] if score @s sit_timer matches 8.. run tag @s remove press_shift
execute as @a if score @s sit_timer matches 8.. run scoreboard players set @s sit_sit 0
execute as @a if score @s sit_timer matches 8.. run scoreboard players set @s sit_timer 0

#Запрет на shift
execute as @a[predicate=sit:sneak] run scoreboard players set @s sit_permiss 1
execute as @a unless predicate sit:sneak if score @s sit_permiss matches 1 run scoreboard players set @s sit_permiss 0

